const router = require('express').Router();
const { login, singup } = require('../controllers/userController.js');


router.route('/login').post(login)
router.route('/signup').post(singup);


module.exports = router;